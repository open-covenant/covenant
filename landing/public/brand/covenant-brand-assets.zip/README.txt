COVENANT BRAND ASSETS
https://opencovenant.org/brand

Covenant is designed for dark backgrounds. Every file in this kit is made for
the Covenant background color, #0D0B16.

LOGO
  covenant-mark.svg / .png           The mark in the Covenant gradient. The default.
  covenant-mark-white.svg / .png     One color, for single-color work.
  covenant-lockup.svg / .png         The mark and the name, in light text.
  covenant-lockup-white.svg / .png   One color: the mark and the name in white.

  Clear space: a fifth of the mark's height on every side.
  Minimum size: the mark at 16 px; the lockup at 120 px wide.
  Do not recolor, stretch, rotate or outline the logo, add effects, move the
  core, rebuild the lockup in another typeface, or place it on a white or light
  background.

ICONS
  covenant-app-icon-1024.png         The mark on the background color, at 69% of the icon's height.
  covenant-avatar-800.png            For circular crops: the mark at 50%.
  favicon.ico, favicon-32.png, apple-touch-icon-180.png

SOCIAL
  covenant-share-card-1200x630.jpg
  covenant-x-header-1500x500.jpg     Keep the left third clear for the avatar.

COLOR
  covenant-colors.css / covenant-colors.json / covenant-palette.txt
  Violet #A03BF0, blue #4C7FDE and mint #1DE3AE, joined in the Covenant
  gradient at 115 degrees, against a deep, dark background (#0D0B16) with
  light text. The gradient has four uses: the mark, the field (Covenant's
  moving imagery), the primary action and one accent per view.

TYPOGRAPHY
  Display: Archivo Expanded (width 125), weight 600, -0.05em tracking, capitals.
  Text:    JetBrains Mono, weights 300 to 600.
  Both are free under the SIL Open Font License, on Google Fonts:
  https://fonts.google.com/specimen/Archivo
  https://fonts.google.com/specimen/JetBrains+Mono

NAME
  Write Covenant with a capital C in running text. The token is $CVNT.

Questions: https://opencovenant.org/contact
